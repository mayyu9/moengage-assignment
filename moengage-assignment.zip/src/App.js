import 'bootstrap/dist/css/bootstrap.min.css';
// import logo from './logo.svg';
import './App.css';
import Layout from './Layout';
import HighLights from './HOC/Highlights';
import Buyers from './HOC/Buyers';
import Countries from './HOC/Countries';
import Income from './HOC/Income';

function App() {
  return (
    <div>
      <Layout />
      <div className="row col-12 mt-4 mx-1">
        <div className="col-6">
          <HighLights />
        </div>
        <div className="col-6">
          <Buyers />
        </div>

      </div>
      <Countries />
      <Income />
    </div>
  );
}

export default App;
