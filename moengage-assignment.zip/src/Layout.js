import React from 'react';
import { Navbar, Container } from 'react-bootstrap';

const Layout = () => {
    return (
        <div>
        {/* <Navbar bg="dark" variant="dark"> */}
    <Container style={{border: '1px solid blue'}}>
      <header>
          <div className="row col-12" style={{border: '1px solid red'}}>
      <div className="col-6">ABC College of engineering</div>
         <div className="col-6">Download Postman Collection</div>
          </div>
      </header>
    </Container>
  {/* </Navbar> */}
    </div>
    )
};

export default Layout;